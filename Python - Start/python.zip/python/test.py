print("shashi")
name=  input()
print(Shashi Kumar)
print(5 + s)
